export default function handleError(caller,err=null){
    console.error(caller);
    console.error(err);
}