/**
 * SPDX-FileCopyrightText: (c) 2000 Liferay, Inc. https://liferay.com
 * SPDX-License-Identifier: LGPL-2.1-or-later OR LicenseRef-Liferay-DXP-EULA-2.0.0-2023-06
 */

import express from 'express';

import {
	corsWithReady,
	liferayJWT,
} from './util/liferay-oauth2-resource-server.js';
import {logger} from './util/logger.js';
import getToken from './util/get-token.js';
import { lookupConfig } from '@rotty3000/config-node';

import {processTransactions, processTransactionsByPayee} from './lib/bank-transaction/index.js';
import onboardingApproved from './lib/onboarding/approved/index.js';

const serverPort = lookupConfig('server.port');
const app = express();

app.use(express.json());
app.use(corsWithReady);
app.use(liferayJWT);


app.get(lookupConfig("readyPath"), (req, res) => {
	res.send('READY');
});

app.post('/bank_transactions', async (req, httpResponse) => {
    try{
        const body = req.body;
        let token = await getToken();
        processTransactions(token.access_token).then(() => {
            processTransactionsByPayee(token.access_token).then(res => {
                httpResponse.sendStatus(200);
            }).catch((err) => {
                throw new Error(`processTransactionsByPayee(): ${err}`);
            });
        }).catch(() => {
            throw new Error(`processTransactionsByPayee(): ${err}`);
        });
    }catch(exception){
        logger.error(exception);
        httpResponse.sendStatus(500);
    }
});

app.post('/onboarding_approved', async (req, httpResponse) => {
    try{
        let token = await getToken();
        let body = req.body.objectEntry.values;

        onboardingApproved(body, token.access_token).then(()=>{
            httpResponse.sendStatus(200);
        }).catch((err)=>{
            throw new Error(err);
        });
    }catch(exception){
        logger.error(exception);
        httpResponse.sendStatus(500);
    }

});

app.listen(serverPort, () => {
	logger.log(`App listening on ${serverPort}`);
});

export default app;
